
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadanie 2</title>
</head>
<body>

<h1>Zadanie 2 - analiza tablicy</h1>

<form method="post">
    <label>Podaj liczby oddzielone przecinkami:</label><br>
    <input type="text" name="liczby" required>
    <button type="submit">Wykonaj</button>
</form>

<?php

if (isset($_POST["liczby"])) {

    $dane = explode(",", $_POST["liczby"]);
    $tab = array();

    foreach ($dane as $element) {
        $element = trim($element);

        if ($element !== "" && preg_match('/^-?\d+$/', $element)) {
            $tab[] = (int)$element;
        }
    }

    if (count($tab) == 0) {
        echo "<p>Wpisz poprawne liczby.</p>";
    } else {

        echo "<h3>Wprowadzona tablica</h3>";
        print_r($tab);

        $min = $tab[0];
        $max = $tab[0];
        $suma = 0;
        $ile3 = 0;

        foreach ($tab as $element) {
            if ($element < $min) $min = $element;
            if ($element > $max) $max = $element;

            $suma += $element;
            $ile3 += substr_count((string)abs($element), "3");
        }

        echo "<h3>1. Minimum i maksimum</h3>";
        echo "Minimum: $min<br>";
        echo "Maksimum: $max<br>";

        echo "<h3>2. Średnia</h3>";
        echo $suma / count($tab);

        echo "<h3>3. Wystąpienia cyfry 3</h3>";
        echo $ile3;

        sort($tab);

        echo "<h3>4. Sortowanie rosnące</h3>";
        print_r($tab);

        $n = count($tab);

        if ($n % 2 == 1) {
            $mediana = $tab[(int)($n / 2)];
        } else {
            $mediana = (
                $tab[(int)($n / 2) - 1] +
                $tab[(int)($n / 2)]
            ) / 2;
        }

        echo "<h3>5. Mediana</h3>";
        echo $mediana;

        echo "<h3>6. Trzy najmniejsze elementy</h3>";

        for ($i = 0; $i < min(3, $n); $i++) {
            echo $tab[$i] . " ";
        }

        echo "<h3>7. Trzy największe elementy</h3>";

        for ($i = max(0, $n - 3); $i < $n; $i++) {
            echo $tab[$i] . " ";
        }

        for ($i = 0; $i < count($tab); $i++) {
            $tab[$i] = $tab[$i] * $tab[$i];
        }

        echo "<h3>8. Elementy podniesione do kwadratu</h3>";
        print_r($tab);

        $parzyste = 0;
        $nieparzyste = 0;

        foreach ($tab as $element) {
            if ($element % 2 == 0) {
                $parzyste++;
            } else {
                $nieparzyste++;
            }
        }

        echo "<h3>9. Parzyste i nieparzyste</h3>";
        echo "Parzyste: $parzyste<br>";
        echo "Nieparzyste: $nieparzyste<br>";

        echo "<h3>10. Liczby podzielne przez 3</h3>";

        foreach ($tab as $element) {
            if ($element % 3 == 0) {
                echo $element . " ";
            }
        }
    }
}
?>

<p><a href="index.php">Powrót do menu</a></p>

</body>
</html>
