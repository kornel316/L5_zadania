
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadanie 1</title>
</head>
<body>

<h1>Zadanie 1 - podstawy tablic</h1>

<?php

$tab1 = array(7, 3, 1, 6, 9, 5, 4, 10, 2, 2);

echo "<h3>1. Piąty element</h3>";
echo $tab1[4] . "<br>";

$tab1[6] = 12;

echo "Tablica tab1: ";
print_r($tab1);

$tab2 = array();

for ($i = 0; $i < count($tab1); $i++) {
    $tab2[$i] = $tab1[$i];
}

echo "<h3>2. Tablica tab2</h3>";
print_r($tab2);

$tab3 = array();

for ($i = 0; $i < count($tab1); $i++) {
    $tab3[$i] = $tab1[$i] + $tab2[$i];
}

echo "<h3>3. Tablica tab3 - suma</h3>";
print_r($tab3);

for ($i = 0; $i < count($tab1); $i++) {
    $tab2[$i] = $tab1[count($tab1) - 1 - $i];
}

echo "<h3>4. Tablica tab2 w odwrotnej kolejności</h3>";
print_r($tab2);

?>

<p><a href="index.php">Powrót do menu</a></p>

</body>
</html>
