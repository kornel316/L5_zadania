
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadanie 4</title>
</head>
<body>

<h1>Zadanie 4 - tablica 100 liczb</h1>

<form method="post">
    <label>Podaj liczbę a:</label><br>
    <input type="number" name="a" value="10" required>
    <button type="submit">Wykonaj</button>
</form>

<?php

if (isset($_POST["a"])) {

    $a = (int)$_POST["a"];
    $A = array();

    for ($i = 0; $i < 100; $i++) {
        $A[$i] = rand(0, 20);
    }

    echo "<h3>Tablica A</h3>";
    print_r($A);

    $max = $A[0];
    $ileMax = 0;

    foreach ($A as $element) {
        if ($element > $max) {
            $max = $element;
        }
    }

    foreach ($A as $element) {
        if ($element == $max) {
            $ileMax++;
        }
    }

    echo "<h3>1. Największa liczba</h3>";
    echo "Maksimum: $max<br>";
    echo "Liczba wystąpień: $ileMax";

    echo "<h3>2. Liczby nieparzyste</h3>";

    foreach ($A as $element) {
        if ($element % 2 != 0) {
            echo $element . " ";
        }
    }

    echo "<h3>3. Elementy o nieparzystych indeksach</h3>";

    for ($i = 1; $i < count($A); $i += 2) {
        echo $A[$i] . " ";
    }

    $ile = 0;

    foreach ($A as $element) {
        if ($element > 5 && $element < 15) {
            $ile++;
        }
    }

    echo "<h3>4. Liczby z przedziału (5, 15)</h3>";
    echo "Liczba elementów: $ile<br>";

    foreach ($A as $element) {
        if ($element > 5 && $element < 15) {
            echo $element . " ";
        }
    }

    $najblizszy = $A[0];

    foreach ($A as $element) {
        if (abs($element - $a) < abs($najblizszy - $a)) {
            $najblizszy = $element;
        }
    }

    echo "<h3>5. Element najbliższy liczbie a</h3>";
    echo "Liczba a: $a<br>";
    echo "Najbliższy element: $najblizszy";

    $indeksMin = 0;

    for ($i = 1; $i < count($A); $i++) {
        if ($A[$i] < $A[$indeksMin]) {
            $indeksMin = $i;
        }
    }

    echo "<h3>6. Poprzednik i następnik minimum</h3>";
    echo "Minimum: " . $A[$indeksMin] . "<br>";
    echo "Indeks minimum: $indeksMin<br>";

    if ($indeksMin > 0) {
        echo "Poprzednik: " . $A[$indeksMin - 1] . "<br>";
    } else {
        echo "Minimum nie ma poprzednika.<br>";
    }

    if ($indeksMin < count($A) - 1) {
        echo "Następnik: " . $A[$indeksMin + 1] . "<br>";
    } else {
        echo "Minimum nie ma następnika.<br>";
    }

    $C = array();

    foreach ($A as $element) {
        if ($element > 10) {
            $C[] = $element;
        }
    }

    echo "<h3>7. Elementy większe od 10</h3>";
    print_r($C);
    echo "<br>Rozmiar tablicy C: " . count($C);

    $B = array();
    $suma = 0;

    for ($i = 0; $i < count($A); $i++) {
        $suma += $A[$i];
        $B[$i] = $suma;
    }

    echo "<h3>8. Tablica sum prefiksowych B</h3>";
    print_r($B);

    rsort($A);

    echo "<h3>9. Tablica posortowana malejąco</h3>";
    print_r($A);

    $czestosci = array_count_values($A);

    echo "<h3>10. Elementy występujące co najmniej 3 razy</h3>";

    $znaleziono = false;

    foreach ($czestosci as $wartosc => $ile) {
        if ($ile >= 3) {
            echo $wartosc . " - wystąpień: " . $ile . "<br>";
            $znaleziono = true;
        }
    }

    if (!$znaleziono) {
        echo "Brak takich elementów.";
    }
}
?>

<p><a href="index.php">Powrót do menu</a></p>

</body>
</html>
