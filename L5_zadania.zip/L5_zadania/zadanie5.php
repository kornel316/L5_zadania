
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadanie 5</title>
</head>
<body>

<h1>Zadanie 5 - ciągi liczbowe</h1>

<form method="post">
    <label>Wybierz ciąg liczbowy:</label><br>

    <select name="ciag">
        <option value="1">Ciąg Fibonacciego</option>
        <option value="2">Potęgi liczby 2</option>
        <option value="3">3, 6, 9, 12, ...</option>
        <option value="4">2, 4, 8, 16, ...</option>
    </select>

    <button type="submit">Wykonaj</button>
</form>

<?php

if (isset($_POST["ciag"])) {

    $wybor = (int)$_POST["ciag"];
    $tab = array();

    if ($wybor == 1) {

        $tab[0] = 0;
        $tab[1] = 1;

        for ($i = 2; $i < 100; $i++) {
            $tab[$i] = $tab[$i - 1] + $tab[$i - 2];
        }

        echo "<h3>Ciąg Fibonacciego</h3>";

    } elseif ($wybor == 2) {

        $tab[0] = 1;

        for ($i = 1; $i < 100; $i++) {
            $tab[$i] = $tab[$i - 1] * 2;
        }

        echo "<h3>Potęgi liczby 2</h3>";

    } elseif ($wybor == 3) {

        for ($i = 0; $i < 100; $i++) {
            $tab[$i] = 3 * ($i + 1);
        }

        echo "<h3>Ciąg 3, 6, 9, 12, ...</h3>";

    } elseif ($wybor == 4) {

        $tab[0] = 2;

        for ($i = 1; $i < 100; $i++) {
            $tab[$i] = $tab[$i - 1] * 2;
        }

        echo "<h3>Ciąg 2, 4, 8, 16, ...</h3>";

    } else {
        echo "<p>Niepoprawny wybór.</p>";
    }

    if ($wybor >= 1 && $wybor <= 4) {
        echo "<p>Liczba elementów: " . count($tab) . "</p>";
        echo "<pre>";
        print_r($tab);
        echo "</pre>";
    }
}
?>

<p><a href="index.php">Powrót do menu</a></p>

</body>
</html>
