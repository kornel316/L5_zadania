
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadanie 3</title>
</head>
<body>

<h1>Zadanie 3 - tablice znaków</h1>

<form method="post">
    <label>Podaj 10 liter:</label><br>
    <input type="text" name="litery" required><br><br>

    <label>Podaj wyraz składający się z 10 znaków:</label><br>
    <input type="text" name="wyraz" required><br><br>

    <button type="submit">Wykonaj</button>
</form>

<?php

if (isset($_POST["litery"]) && isset($_POST["wyraz"])) {

    $litery = preg_split(
        '//u',
        $_POST["litery"],
        -1,
        PREG_SPLIT_NO_EMPTY
    );

    $wyraz = preg_split(
        '//u',
        $_POST["wyraz"],
        -1,
        PREG_SPLIT_NO_EMPTY
    );

    if (count($litery) != 10) {
        echo "<p>Wpisz dokładnie 10 liter.</p>";
    } elseif (count($wyraz) != 10) {
        echo "<p>Wyraz musi mieć dokładnie 10 znaków.</p>";
    } elseif (!function_exists("mb_strtolower")) {
        echo "<p>Włącz rozszerzenie mbstring w konfiguracji PHP.</p>";
    } else {

        $tab = $litery;

        echo "<h3>1. Tablica liter</h3>";
        print_r($tab);

        $tab = $wyraz;

        echo "<h3>2. Tablica z wyrazem</h3>";
        print_r($tab);

        for ($i = 0; $i < count($tab); $i++) {

            $mala = mb_strtolower($tab[$i], "UTF-8");
            $duza = mb_strtoupper($tab[$i], "UTF-8");

            if ($tab[$i] === $mala) {
                $tab[$i] = $duza;
            } else {
                $tab[$i] = $mala;
            }
        }

        echo "<h3>3. Zamiana wielkości liter</h3>";
        print_r($tab);

        shuffle($tab);

        echo "<h3>4. Losowa kolejność</h3>";
        print_r($tab);
    }
}
?>

<p><a href="index.php">Powrót do menu</a></p>

</body>
</html>
