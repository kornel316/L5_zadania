
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadania - tablice PHP</title>
</head>
<body>

<h1>Zadania z tablic w PHP</h1>

<ol>
    <li><a href="zadanie1.php">Podstawy tablic</a></li>
    <li><a href="zadanie2.php">Analiza tablicy</a></li>
    <li><a href="zadanie3.php">Tablice znaków</a></li>
    <li><a href="zadanie4.php">Tablica 100 losowych liczb</a></li>
    <li><a href="zadanie5.php">Ciągi liczbowe</a></li>
</ol>

</body>
</html>
